# ⚡ Yellow Light — Invoice Manager
## Deployment Guide (Supabase + Vercel)

---

## STEP 1 — Set up Supabase (free database)

1. Go to **https://app.supabase.com** and create a free account
2. Click **"New Project"** → name it `yellowlight` → pick a region → set a password → Create
3. Wait ~2 minutes for it to provision
4. Go to **SQL Editor** (left sidebar) → click **"New Query"**
5. Copy and paste the SQL below, then click **Run**:

```sql
create table if not exists business (
  id uuid primary key default gen_random_uuid(),
  user_id text not null unique,
  name text default 'Yellow Light',
  email text default '',
  phone text default '',
  address text default '',
  website text default '',
  tax_id text default '',
  payment_terms text default 'Net 30',
  currency text default 'USD',
  next_num integer default 1001,
  created_at timestamptz default now()
);

create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  name text not null,
  company text default '',
  email text default '',
  phone text default '',
  address text default '',
  notes text default '',
  created_at timestamptz default now()
);

create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  number text not null,
  date text,
  due_date text,
  status text default 'draft',
  client_name text,
  client_email text,
  client_phone text,
  client_address text,
  project_name text,
  po_number text,
  items jsonb default '[]',
  tax_rate numeric default 0,
  discount numeric default 0,
  notes text default '',
  created_at timestamptz default now()
);

create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  description text not null,
  amount numeric default 0,
  category text default 'General',
  date text,
  receipt text default '',
  created_at timestamptz default now()
);

alter table business enable row level security;
alter table clients enable row level security;
alter table invoices enable row level security;
alter table expenses enable row level security;

create policy "public access" on business for all using (true);
create policy "public access" on clients for all using (true);
create policy "public access" on invoices for all using (true);
create policy "public access" on expenses for all using (true);
```

6. Go to **Settings → API** (left sidebar)
7. Copy your **Project URL** and **anon public** key — you'll need them next

---

## STEP 2 — Upload to GitHub

1. Go to **https://github.com** → sign in (or create free account)
2. Click **"New repository"** → name it `yellowlight-invoices` → **Public** → Create
3. On your computer, open Terminal/Command Prompt in this folder and run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/yellowlight-invoices.git
git push -u origin main
```

*(Replace YOUR_USERNAME with your GitHub username)*

---

## STEP 3 — Deploy on Vercel

1. Go to **https://vercel.com** → sign in with GitHub
2. Click **"Add New Project"** → Import `yellowlight-invoices`
3. In the **Environment Variables** section, add:
   - `REACT_APP_SUPABASE_URL` → paste your Supabase Project URL
   - `REACT_APP_SUPABASE_ANON_KEY` → paste your Supabase anon key
4. Click **Deploy** — wait ~2 minutes
5. 🎉 Your app is live at `https://yellowlight-invoices.vercel.app`

---

## STEP 4 — Custom Domain (optional)

In Vercel → Your Project → **Settings → Domains**
Add your own domain like `invoices.yellowlight.com`

---

## Summary

| Service | Cost | What it does |
|---------|------|--------------|
| Supabase | Free (up to 50k rows) | Stores all your data |
| Vercel | Free | Hosts your web app |
| GitHub | Free | Stores your code |

Your app will be available 24/7 from any device, any browser.
