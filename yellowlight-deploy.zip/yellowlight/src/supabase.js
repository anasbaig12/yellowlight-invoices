import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.REACT_APP_SUPABASE_URL;
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/* ─────────────────────────────────────────────────────
   SUPABASE SQL — run this in your Supabase SQL Editor
   once to create the required tables.
   Go to: app.supabase.com → SQL Editor → New Query
─────────────────────────────────────────────────────

-- Business settings (single row per user)
create table if not exists business (
  id uuid primary key default gen_random_uuid(),
  user_id text not null unique,
  name text default 'Yellow Light',
  email text default '',
  phone text default '',
  address text default '',
  website text default '',
  tax_id text default '',
  payment_terms text default 'Net 30',
  currency text default 'USD',
  next_num integer default 1001,
  created_at timestamptz default now()
);

-- Clients
create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  name text not null,
  company text default '',
  email text default '',
  phone text default '',
  address text default '',
  notes text default '',
  created_at timestamptz default now()
);

-- Invoices
create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  number text not null,
  date text,
  due_date text,
  status text default 'draft',
  client_name text,
  client_email text,
  client_phone text,
  client_address text,
  project_name text,
  po_number text,
  items jsonb default '[]',
  tax_rate numeric default 0,
  discount numeric default 0,
  notes text default '',
  created_at timestamptz default now()
);

-- Expenses
create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,
  description text not null,
  amount numeric default 0,
  category text default 'General',
  date text,
  receipt text default '',
  created_at timestamptz default now()
);

-- Enable Row Level Security (open policy for now — add auth later)
alter table business enable row level security;
alter table clients enable row level security;
alter table invoices enable row level security;
alter table expenses enable row level security;

create policy "public access" on business for all using (true);
create policy "public access" on clients for all using (true);
create policy "public access" on invoices for all using (true);
create policy "public access" on expenses for all using (true);

─────────────────────────────────────────────────── */
